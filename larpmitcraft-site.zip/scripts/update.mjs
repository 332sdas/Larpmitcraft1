// Fetches each member's latest uploads from YouTube's public RSS feeds
// and writes data/videos.json. Needs Node 18+ (no dependencies).
import fs from "node:fs";

const members = JSON.parse(fs.readFileSync("members.json", "utf8"));
const read = (p, d) => { try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch { return d; } };
const ids = read("data/channel-ids.json", {});
const prev = read("data/videos.json", { videos: [] }).videos;
const UA = { "user-agent": "Mozilla/5.0", "accept-language": "en-US,en;q=0.9" };
const PER_MEMBER = 6, TOTAL = 60;

const unescapeXml = s => s.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
  .replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'");

async function channelId(m) {
  if (m.id) return m.id;
  const direct = m.url.match(/\/channel\/(UC[\w-]{22})/);
  if (direct) return direct[1];
  if (ids[m.url]) return ids[m.url];
  const html = await (await fetch(m.url, { headers: UA })).text();
  const hit = html.match(/<link rel="canonical" href="https:\/\/www\.youtube\.com\/channel\/(UC[\w-]{22})"/)
    || html.match(/"externalId":"(UC[\w-]{22})"/) || html.match(/"channelId":"(UC[\w-]{22})"/);
  if (!hit) throw new Error("could not find channel id");
  ids[m.url] = hit[1];
  return hit[1];
}

async function latest(m) {
  const id = await channelId(m);
  const res = await fetch(`https://www.youtube.com/feeds/videos.xml?channel_id=${id}`, { headers: UA });
  if (!res.ok) throw new Error("feed status " + res.status);
  const xml = await res.text();
  return [...xml.matchAll(/<entry>([\s\S]*?)<\/entry>/g)].slice(0, PER_MEMBER).map(([, e]) => {
    const vid = e.match(/<yt:videoId>(.*?)<\/yt:videoId>/)[1];
    return {
      title: unescapeXml(e.match(/<title>(.*?)<\/title>/)[1]),
      channel: m.name,
      url: `https://www.youtube.com/watch?v=${vid}`,
      thumb: `https://i.ytimg.com/vi/${vid}/mqdefault.jpg`,
      published: e.match(/<published>(.*?)<\/published>/)[1],
    };
  });
}

const out = [];
for (const m of members) {
  try { out.push(...await latest(m)); console.log("ok  ", m.name); }
  catch (err) {
    console.log("FAIL", m.name, "-", err.message, "(keeping previous videos)");
    out.push(...prev.filter(v => v.channel === m.name));
  }
}
out.sort((a, b) => new Date(b.published) - new Date(a.published));
fs.mkdirSync("data", { recursive: true });
fs.writeFileSync("data/videos.json", JSON.stringify({ updated: new Date().toISOString(), videos: out.slice(0, TOTAL) }, null, 1));
fs.writeFileSync("data/channel-ids.json", JSON.stringify(ids, null, 1));
