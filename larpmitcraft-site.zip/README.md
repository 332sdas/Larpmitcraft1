# Larpmitcraft site (auto-updating)

The Latest tab fills itself with each member's newest YouTube uploads. A GitHub Action
runs every hour, reads the public feeds, and saves `data/videos.json`; the page shows it.

## Setup (about 5 minutes, free)
1. Make a free account at github.com and create a **new public repository** (any name).
2. Upload everything in this folder, including the hidden `.github` folder, to the repo
   (on github.com: Add file > Upload files; on a computer, drag the whole folder in).
3. Repo **Settings > Pages**: Source = "Deploy from a branch", Branch = `main`, folder `/ (root)`. Save.
4. Repo **Actions** tab: if it asks, enable workflows. Open "Update videos" and click **Run workflow** once.
   After about a minute `data/videos.json` fills in, and from then on it refreshes hourly.
5. Your site is at `https://YOUR-USERNAME.github.io/REPO-NAME/` (shown on the Pages settings page).

## Changing things
- **Members:** edit `members.json` (`name` and `url` for each). The sidebar list in `index.html` is separate, so edit both.
- **A member never shows videos:** check the Actions log for a "FAIL" line. Adding their channel id
  (starts with `UC`) as `"id": "UC..."` in `members.json` fixes it.
- GitHub pauses scheduled runs if a repo is untouched for 60 days. If that happens, click Run workflow to wake it.
